import React, { useState } from 'react';
import { DeviceInfo } from '../types';
import { COLORS } from '../constants';

interface DeviceInfoPanelProps {
  device: DeviceInfo;
  onClose: () => void;
}

const DeviceInfoPanel: React.FC<DeviceInfoPanelProps> = ({ device, onClose }) => {
  const [imageError, setImageError] = useState(false);
  const [imageLoading, setImageLoading] = useState(true);
  const [isZoomed, setIsZoomed] = useState(false);

  const getLayerColor = (layer: string) => {
    return COLORS[layer as keyof typeof COLORS] || COLORS.slate;
  };

  return (
    <>
      <div className="absolute top-6 right-6 bottom-6 w-96 bg-slate-900/95 backdrop-blur-xl border border-slate-700 shadow-2xl rounded-2xl flex flex-col z-[100] animate-in slide-in-from-right duration-300 overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex justify-between items-start">
          <div>
            <div 
              className="text-[10px] font-bold px-2 py-0.5 rounded-sm inline-block mb-2 uppercase"
              style={{ backgroundColor: `${getLayerColor(device.layer)}33`, color: getLayerColor(device.layer) }}
            >
              {device.layer === 'cables' ? 'LOGIKA KABLI' : 'ELEMENT SPRZĘTOWY'}
            </div>
            <h2 className="text-xl font-bold text-white leading-tight">{device.name}</h2>
            <p className="text-slate-400 text-xs font-medium">{device.model}</p>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-slate-800 rounded-lg text-slate-500 hover:text-white transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content */}
        <div className="flex-grow p-6 overflow-y-auto custom-scrollbar space-y-8">
          {/* Device Function */}
          <section>
            <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-slate-600"></span>
              Funkcja w studio
            </h3>
            <p className="text-sm text-slate-300 leading-relaxed italic">
              "{device.function}"
            </p>
          </section>

          {/* Cable Logic */}
          {device.cableInfo && (
            <section className="bg-slate-800/40 p-4 rounded-xl border border-slate-700/50">
              <h3 className="text-[10px] font-bold text-sky-400 uppercase tracking-widest mb-4">Schemat Połączenia</h3>
              <div className="flex items-center gap-3 text-xs">
                <div className="flex-1">
                  <p className="text-slate-500 text-[9px] uppercase mb-1">Z URZĄDZENIA</p>
                  <p className="text-white font-bold">{device.cableInfo.from}</p>
                  <p className="text-slate-400 text-[10px]">Port: {device.cableInfo.portFrom}</p>
                </div>
                <div className="text-sky-500 animate-pulse">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </div>
                <div className="flex-1 text-right">
                  <p className="text-slate-500 text-[9px] uppercase mb-1">DO URZĄDZENIA</p>
                  <p className="text-white font-bold">{device.cableInfo.to}</p>
                  <p className="text-slate-400 text-[10px]">Port: {device.cableInfo.portTo}</p>
                </div>
              </div>
            </section>
          )}

          {/* Connection Logic (Regular Devices) */}
          {!device.cableInfo && device.connectionLogic && (
            <section>
              <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-slate-600"></span>
                Logika Połączeń
              </h3>
              <p className="text-sm text-slate-300 leading-relaxed">
                {device.connectionLogic}
              </p>
            </section>
          )}

          {/* Port Diagram Image */}
          {!device.cableInfo && device.portsDiagram && (
            <section>
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-600"></span>
                  Schemat Portów (Real View)
                </h3>
                {!imageError && !imageLoading && (
                   <span className="text-[9px] text-sky-500 font-bold animate-pulse">KLIKNIJ, ABY POWIĘKSZYĆ</span>
                )}
              </div>
              
              <div 
                className={`rounded-xl overflow-hidden border border-slate-700 bg-black/40 group relative min-h-[200px] flex items-center justify-center ${!imageError && !imageLoading ? 'cursor-zoom-in' : ''}`}
                onClick={() => !imageError && !imageLoading && setIsZoomed(true)}
              >
                {imageLoading && !imageError && (
                  <div className="absolute inset-0 flex items-center justify-center bg-slate-900 animate-pulse">
                    <div className="w-6 h-6 border-2 border-sky-500 border-t-transparent rounded-full animate-spin"></div>
                  </div>
                )}
                
                {imageError ? (
                  <div className="p-8 text-center flex flex-col items-center gap-3" onClick={(e) => e.stopPropagation()}>
                    <svg className="w-12 h-12 text-slate-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <p className="text-[10px] text-slate-500 uppercase font-bold tracking-tight leading-relaxed">
                      Błąd wczytywania grafiki.<br/>
                      <span className="text-sky-500/50">Upewnij się, że plik na Google Drive jest udostępniony publicznie.</span>
                    </p>
                    <a 
                      href={device.portsDiagram} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="mt-2 text-[9px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1 rounded transition-colors"
                    >
                      Otwórz źródło w nowej karcie
                    </a>
                  </div>
                ) : (
                  <>
                    <img 
                      src={device.portsDiagram} 
                      alt={`${device.name} Ports`} 
                      className={`w-full h-auto transition-all duration-500 group-hover:scale-105 ${imageLoading ? 'opacity-0' : 'opacity-100'}`}
                      onLoad={() => setImageLoading(false)}
                      onError={() => {
                        setImageError(true);
                        setImageLoading(false);
                      }}
                    />
                    {!imageLoading && (
                      <div className="absolute inset-0 bg-sky-500/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <svg className="w-10 h-10 text-white drop-shadow-lg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                        </svg>
                      </div>
                    )}
                  </>
                )}
                <div className="absolute inset-0 ring-1 ring-inset ring-white/10 rounded-xl pointer-events-none"></div>
              </div>
            </section>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950/50 border-t border-slate-800 text-[8px] text-slate-600 text-center uppercase tracking-tighter">
          Technical Documentation System // Recording Studio v2.0 // Generated Live
        </div>
      </div>

      {/* Lightbox / Enlarged View */}
      {isZoomed && (
        <div 
          className="fixed inset-0 z-[200] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-8 animate-in fade-in duration-300 cursor-zoom-out"
          onClick={() => setIsZoomed(false)}
        >
          <div className="absolute top-6 right-8 flex items-center gap-4">
             <div className="text-right">
                <p className="text-white font-bold text-sm">{device.name}</p>
                <p className="text-slate-400 text-[10px] uppercase tracking-widest">{device.model} // Port Scheme</p>
             </div>
             <button 
              className="p-3 bg-white/10 hover:bg-white/20 rounded-full text-white transition-all border border-white/10"
              onClick={() => setIsZoomed(false)}
            >
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          <img 
            src={device.portsDiagram} 
            alt={device.name}
            className="max-w-full max-h-full object-contain rounded-lg shadow-[0_0_50px_rgba(0,0,0,0.5)] border border-white/5 animate-in zoom-in-95 duration-300"
            onClick={(e) => e.stopPropagation()}
          />
          
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 px-4 py-2 bg-slate-900/50 border border-slate-800 rounded-full text-[10px] text-slate-400 uppercase tracking-widest pointer-events-none">
            Kliknij w dowolnym miejscu, aby zamknąć
          </div>
        </div>
      )}
    </>
  );
};

export default DeviceInfoPanel;