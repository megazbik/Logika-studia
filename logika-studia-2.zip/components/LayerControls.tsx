import React from 'react';
import { LayerState, LayerType } from '../types';
import { COLORS } from '../constants';

interface LayerControlsProps {
  layers: LayerState;
  onToggle: (layer: keyof LayerState) => void;
}

const LayerControls: React.FC<LayerControlsProps> = ({ layers, onToggle }) => {
  const controls: { key: keyof LayerState; label: string; color: string; description: string }[] = [
    { key: 'turquoise', label: 'WARSTWA STAŁA', color: COLORS.turquoise, description: 'Meble, panele, monitory' },
    { key: 'yellow', label: 'WARSTWA WIDEO', color: COLORS.yellow, description: 'Kamery i mikser video' },
    { key: 'purple', label: 'WARSTWA OŚWIETLENIA', color: COLORS.purple, description: 'Lampy i konsola DMX' },
    { key: 'green', label: 'WARSTWA AUDIO', color: COLORS.green, description: 'Mikrofony i mikser audio' },
    { key: 'cables', label: 'WARSTWA KABLI', color: COLORS.slate, description: 'Połączenia sygnałowe' },
  ];

  return (
    <div className="w-80 h-full bg-slate-900/90 backdrop-blur-lg border-r border-slate-700 p-6 flex flex-col gap-6 z-50">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-3 h-3 bg-sky-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(56,189,248,0.5)]"></div>
        <h2 className="text-sm font-bold text-slate-400 tracking-tighter uppercase">Zarządzanie Widocznością</h2>
      </div>

      <div className="space-y-4">
        {controls.map((control) => (
          <button
            key={control.key}
            onClick={() => onToggle(control.key)}
            className={`w-full group relative flex flex-col p-4 rounded-xl border transition-all duration-300 ${
              layers[control.key] 
                ? 'bg-slate-800 border-slate-600 shadow-lg translate-x-1' 
                : 'bg-slate-900/40 border-slate-800 opacity-60 hover:opacity-80'
            }`}
          >
            <div className="flex justify-between items-center mb-1">
              <span className={`text-[11px] font-black tracking-widest ${layers[control.key] ? 'text-white' : 'text-slate-500'}`}>
                {control.label}
              </span>
              <div 
                className={`w-4 h-4 rounded-full border-2 transition-all ${
                  layers[control.key] ? 'scale-110' : 'scale-90 border-slate-700'
                }`}
                style={{ 
                  backgroundColor: layers[control.key] ? control.color : 'transparent',
                  borderColor: control.color
                }}
              />
            </div>
            <p className="text-[10px] text-left text-slate-500 font-medium">
              {control.description}
            </p>
          </button>
        ))}
      </div>

      <div className="mt-auto pt-6 border-t border-slate-800">
        <div className="bg-slate-800/50 rounded-lg p-4">
          <h3 className="text-[9px] text-slate-500 font-bold mb-2 uppercase">Legenda Systemowa</h3>
          <div className="space-y-1 text-[9px] text-slate-400">
            <div className="flex justify-between">
              <span>Tryb inspekcji</span>
              <span className="text-sky-500">AKTYWNY</span>
            </div>
            <div className="flex justify-between">
              <span>Pan & Zoom</span>
              <span className="text-slate-200">KÓŁKO / DRAG</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LayerControls;