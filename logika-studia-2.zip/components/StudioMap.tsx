
import React, { useRef } from 'react';
import { TransformWrapper, TransformComponent } from 'react-zoom-pan-pinch';
import { LayerState } from '../types';
import { COLORS } from '../constants';

interface StudioMapProps {
  layers: LayerState;
  onDeviceClick: (id: string) => void;
  selectedDeviceId: string | null;
}

const StudioMap: React.FC<StudioMapProps> = ({ layers, onDeviceClick, selectedDeviceId }) => {
  const svgRef = useRef<SVGSVGElement>(null);

  // SVG dimensions for the viewport
  const WIDTH = 1200;
  const HEIGHT = 800;

  const InteractiveElement = ({ 
    id, 
    children, 
    layer 
  }: { 
    id: string; 
    children?: React.ReactNode; 
    layer: keyof LayerState 
  }) => {
    const isVisible = layers[layer];
    const isSelected = selectedDeviceId === id;

    if (!isVisible) return null;

    return (
      <g 
        onClick={(e) => {
          e.stopPropagation();
          onDeviceClick(id);
        }}
        className={`cursor-pointer transition-all duration-300 group`}
      >
        {isSelected && (
           <rect 
            x="-5%" y="-5%" width="110%" height="110%" 
            className="fill-none stroke-white/20 animate-pulse stroke-[1px]"
          />
        )}
        {children}
        {/* Hover overlay filter */}
        <g className="opacity-0 group-hover:opacity-10 pointer-events-none">
          {children}
        </g>
      </g>
    );
  };

  return (
    <TransformWrapper
      initialScale={0.8}
      centerOnInit={true}
      minScale={0.2}
      maxScale={5}
    >
      <TransformComponent wrapperClass="!w-full !h-full" contentClass="!w-full !h-full flex items-center justify-center">
        <svg
          ref={svgRef}
          viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
          className="max-w-full max-h-full drop-shadow-2xl filter"
          preserveAspectRatio="xMidYMid meet"
        >
          {/* BACKGROUND DECORATION */}
          <rect width={WIDTH} height={HEIGHT} fill="none" />

          {/* TURQUOISE LAYER (STATIC) */}
          <g opacity={layers.turquoise ? 1 : 0.2}>
            {/* Top Acoustic Panel */}
            <rect x="250" y="40" width="700" height="80" fill={COLORS.turquoise} fillOpacity="0.2" stroke={COLORS.turquoise} strokeWidth="2" />
            <text x="600" y="90" textAnchor="middle" fill="white" className="text-3xl font-bold uppercase tracking-widest opacity-80 pointer-events-none">Panele akustyczne</text>

            {/* Central Table */}
            <rect x="520" y="240" width="100" height="250" fill={COLORS.turquoise} stroke={COLORS.turquoise} strokeWidth="2" />

            {/* Chairs around Table */}
            <rect x="440" y="310" width="60" height="70" rx="15" fill={COLORS.turquoise} fillOpacity="0.1" stroke={COLORS.turquoise} />
            <rect x="640" y="260" width="60" height="70" rx="15" fill={COLORS.turquoise} fillOpacity="0.1" stroke={COLORS.turquoise} />
            <rect x="640" y="360" width="60" height="70" rx="15" fill={COLORS.turquoise} fillOpacity="0.1" stroke={COLORS.turquoise} />

            {/* Control Desk */}
            <rect x="700" y="750" width="300" height="130" fill={COLORS.turquoise} stroke={COLORS.turquoise} strokeWidth="2" transform="translate(0, -50)" />
            
            {/* Monitors */}
            <rect x="715" y="735" width="90" height="12" fill={COLORS.turquoise} stroke={COLORS.turquoise} transform="translate(0, -50)" />
            <text x="760" y="745" textAnchor="middle" fill="white" className="text-[10px]" transform="translate(0, -50)">Monitor 1</text>
            <rect x="815" y="735" width="90" height="12" fill={COLORS.turquoise} stroke={COLORS.turquoise} transform="translate(0, -50)" />
            <text x="860" y="745" textAnchor="middle" fill="white" className="text-[10px]" transform="translate(0, -50)">Monitor 2</text>

            {/* Director's Chairs (Static - under the desk) */}
            <rect x="740" y="780" width="55" height="60" rx="12" fill={COLORS.turquoise} fillOpacity="0.15" stroke={COLORS.turquoise} strokeWidth="1.5" />
            <rect x="835" y="780" width="55" height="60" rx="12" fill={COLORS.turquoise} fillOpacity="0.15" stroke={COLORS.turquoise} strokeWidth="1.5" />
          </g>

          {/* CABLES LAYER (Dynamic visibility based on endpoint layers) */}
          {layers.cables && (
            <g className="opacity-80 transition-opacity">
              {/* Audio Cables (Green must be ON) */}
              {layers.green && (
                <>
                  <InteractiveElement id="cable_mic1" layer="cables">
                    <path d="M570,300 L570,200 L825,200 L825,700" fill="none" stroke="transparent" strokeWidth="15" />
                    <path d="M570,300 L570,200 L825,200 L825,700" fill="none" stroke={COLORS.green} strokeWidth="1.5" strokeDasharray="4 4" />
                  </InteractiveElement>
                  <InteractiveElement id="cable_mic2" layer="cables">
                    <path d="M570,350 L570,220 L840,220 L840,700" fill="none" stroke="transparent" strokeWidth="15" />
                    <path d="M570,350 L570,220 L840,220 L840,700" fill="none" stroke={COLORS.green} strokeWidth="1.5" strokeDasharray="4 4" />
                  </InteractiveElement>
                  <InteractiveElement id="cable_mic3" layer="cables">
                    <path d="M570,400 L570,240 L855,240 L855,700" fill="none" stroke="transparent" strokeWidth="15" />
                    <path d="M570,400 L570,240 L855,240 L855,700" fill="none" stroke={COLORS.green} strokeWidth="1.5" strokeDasharray="4 4" />
                  </InteractiveElement>
                </>
              )}
              {/* Video Cables (Yellow must be ON) */}
              {layers.yellow && (
                <InteractiveElement id="cable_cam1" layer="cables">
                  <path d="M550,650 L720,650 L720,700" fill="none" stroke="transparent" strokeWidth="15" />
                  <path d="M650,650 L730,650 L730,700" fill="none" stroke="transparent" strokeWidth="15" />
                  <path d="M550,650 L720,650 L720,700" fill="none" stroke={COLORS.yellow} strokeWidth="2" strokeDasharray="6 2" />
                  <path d="M650,650 L730,650 L730,700" fill="none" stroke={COLORS.yellow} strokeWidth="2" strokeDasharray="6 2" />
                </InteractiveElement>
              )}
              {/* DMX Cables Daisy Chain (Purple must be ON) */}
              {layers.purple && (
                <InteractiveElement id="cable_dmx" layer="cables">
                  <path d="M930,710 L965,600 L765,555 L965,250 L265,250 L465,555 L265,600" fill="none" stroke="transparent" strokeWidth="15" />
                  <path d="M930,710 L965,600 L765,555 L965,250 L265,250 L465,555 L265,600" fill="none" stroke={COLORS.purple} strokeWidth="2" strokeDasharray="3 3" />
                </InteractiveElement>
              )}
            </g>
          )}

          {/* YELLOW LAYER (VIDEO) */}
          <InteractiveElement id="cam_1" layer="yellow">
            <circle cx="550" cy="650" r="35" fill={COLORS.yellow} stroke="white" strokeWidth="1" />
            <text x="550" y="640" textAnchor="middle" fill="black" className="text-[9px] font-bold">Panasonic</text>
            <text x="550" y="652" textAnchor="middle" fill="black" className="text-[8px]">HC-X2000</text>
          </InteractiveElement>

          <InteractiveElement id="cam_2" layer="yellow">
            <circle cx="650" cy="650" r="35" fill={COLORS.yellow} stroke="white" strokeWidth="1" />
            <text x="650" y="640" textAnchor="middle" fill="black" className="text-[9px] font-bold">Panasonic</text>
            <text x="650" y="652" textAnchor="middle" fill="black" className="text-[8px]">HC-X2000</text>
          </InteractiveElement>

          {/* Main Video Mixer on the left-ish */}
          <InteractiveElement id="atem_extreme" layer="yellow">
            <rect x="715" y="700" width="80" height="30" fill={COLORS.yellow} stroke="white" />
            <text x="755" y="715" textAnchor="middle" fill="black" className="text-[6px] font-bold">ATEM Extreme ISO</text>
          </InteractiveElement>

          {/* PURPLE LAYER (LIGHTING) */}
          <InteractiveElement id="light_p1" layer="purple">
            <rect x="250" y="150" width="30" height="100" fill={COLORS.purple} stroke="white" transform="rotate(-30, 265, 200)" />
            <text x="265" y="200" textAnchor="middle" fill="white" className="text-[8px]" transform="rotate(-30, 265, 200)">Lishuai P1380</text>
          </InteractiveElement>

          <InteractiveElement id="light_p2" layer="purple">
            <rect x="950" y="150" width="30" height="100" fill={COLORS.purple} stroke="white" transform="rotate(30, 965, 200)" />
            <text x="965" y="200" textAnchor="middle" fill="white" className="text-[8px]" transform="rotate(30, 965, 200)">Lishuai P1380</text>
          </InteractiveElement>

          <InteractiveElement id="light_p3" layer="purple">
            <rect x="250" y="500" width="30" height="100" fill={COLORS.purple} stroke="white" transform="rotate(30, 265, 550)" />
            <text x="265" y="550" textAnchor="middle" fill="white" className="text-[8px]" transform="rotate(30, 265, 550)">Lishuai P1380</text>
          </InteractiveElement>

          <InteractiveElement id="light_p4" layer="purple">
            <rect x="950" y="500" width="30" height="100" fill={COLORS.purple} stroke="white" transform="rotate(-30, 965, 550)" />
            <text x="965" y="550" textAnchor="middle" fill="white" className="text-[8px]" transform="rotate(-30, 965, 550)">Lishuai P1380</text>
          </InteractiveElement>

          <InteractiveElement id="light_c1" layer="purple">
            <polygon points="450,530 480,530 495,555 480,580 450,580 435,555" fill={COLORS.purple} stroke="white" />
            <text x="465" y="555" textAnchor="middle" fill="white" className="text-[7px]">Coolcam 300X</text>
          </InteractiveElement>

          <InteractiveElement id="light_c2" layer="purple">
            <polygon points="750,530 780,530 795,555 780,580 750,580 735,555" fill={COLORS.purple} stroke="white" />
            <text x="765" y="555" textAnchor="middle" fill="white" className="text-[7px]">Coolcam 300X</text>
          </InteractiveElement>

          {/* Ibiza DMX Console on the right */}
          <InteractiveElement id="dmx_console" layer="purple">
            <rect x="905" y="710" width="50" height="20" fill={COLORS.purple} stroke="white" />
            <text x="930" y="722" textAnchor="middle" fill="white" className="text-[5px] font-bold">Ibiza DMX</text>
          </InteractiveElement>

          {/* GREEN LAYER (AUDIO) */}
          <InteractiveElement id="mic_1" layer="green">
            <circle cx="570" cy="300" r="15" fill={COLORS.green} stroke="white" />
            <text x="570" y="303" textAnchor="middle" fill="black" className="text-[5px] font-bold">AT2020</text>
          </InteractiveElement>

          <InteractiveElement id="mic_2" layer="green">
            <circle cx="570" cy="350" r="15" fill={COLORS.green} stroke="white" />
            <text x="570" y="353" textAnchor="middle" fill="black" className="text-[5px] font-bold">AT2020</text>
          </InteractiveElement>

          <InteractiveElement id="mic_3" layer="green">
            <circle cx="570" cy="400" r="15" fill={COLORS.green} stroke="white" />
            <text x="570" y="403" textAnchor="middle" fill="black" className="text-[5px] font-bold">AT2020</text>
          </InteractiveElement>

          {/* Audio Mixer in the center-right */}
          <InteractiveElement id="audio_mixer" layer="green">
            <rect x="815" y="700" width="70" height="30" fill={COLORS.green} fillOpacity="0.5" stroke="white" strokeDasharray="2" />
            <text x="850" y="720" textAnchor="middle" fill="black" className="text-[5px] font-bold">DNA Audio</text>
          </InteractiveElement>
        </svg>
      </TransformComponent>
    </TransformWrapper>
  );
};

export default StudioMap;
